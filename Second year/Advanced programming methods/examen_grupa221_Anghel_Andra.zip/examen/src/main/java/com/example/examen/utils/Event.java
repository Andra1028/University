package com.example.examen.utils;

public interface Event {
}
