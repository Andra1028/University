package com.example.examen.utils;

public interface Observer {
    void update();
}
