

create   procedure insertStudenti
as 
begin

DECLARE @i INT = 1
DECLARE @j INT = 1
DECLARE @teamId INT
DECLARE @schoolId INT

WHILE @i <= 30
BEGIN
  SET @teamId = @i
  SET @schoolId = @i
  WHILE @j <= 15
  BEGIN
    INSERT INTO students (id, student_name, id_team, id_school)
    VALUES (@j + (@i-1)*15, 'Student ' + CAST(@j AS VARCHAR(10)), @teamId, @schoolId)
    SET @j = @j + 1
  END
  SET @j = 1
  SET @i = @i + 1
end
end

exec insertStudenti

INSERT INTO games (id, id_team1, id_team2, game_date) VALUES
(1, 1, 2, '2022-01-01 12:00:00'),
(2, 3, 4, '2022-01-02 14:00:00'),
(3, 5, 6, '2022-01-03 16:00:00'),
(4, 7, 8, '2022-01-04 18:00:00'),
(5, 9, 10, '2022-01-05 20:00:00'),
(6, 11, 12, '2022-01-06 22:00:00'),
(7, 13, 14, '2022-01-07 00:00:00'),
(8, 15, 16, '2022-01-08 02:00:00'),
(9, 17, 18, '2022-01-09 04:00:00'),
(10, 19, 20, '2022-01-10 06:00:00');

go

