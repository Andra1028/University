create   procedure insertPlayersGames
as
begin
DECLARE @i INT = 1
DECLARE @playerId INT
DECLARE @gameId INT
DECLARE @points INT
DECLARE @team1 INT
DECLARE @team2 INT

WHILE @i <= (SELECT COUNT(*) FROM games)
BEGIN
  SELECT @gameId = id, @team1 = id_team1, @team2 = id_team2 FROM games WHERE id = @i
  INSERT INTO players_games (id_player, id_game, points)
  SELECT id, @gameId, ROUND((RAND() * 100), 0)
  FROM students
  WHERE id_team = @team1 OR id_team = @team2
  SET @i = @i + 1
END
end
go

